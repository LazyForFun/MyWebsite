#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: apps.py 2139 2021-12-29 00:39:10Z Jacky $
#
# Copyright (c) 2021 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Jacky $
# $Date: 2021-12-29 08:39:10 +0800 (週三, 29 十二月 2021) $
# $Revision: 2139 $

from django.apps import AppConfig

class GradeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'grade'
