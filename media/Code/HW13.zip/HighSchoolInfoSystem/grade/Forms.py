#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: Forms.py 2211 2022-02-20 09:25:53Z Jacky $
#
# Copyright (c) 2022 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Jacky $
# $Date: 2022-02-20 17:25:53 +0800 (週日, 20 二月 2022) $
# $Revision: 2211 $

from django import forms

from .Validators import validatePassword


class PasswordForm(forms.Form):

    password = forms.CharField(validators=[validatePassword])
    passwordCheck = forms.CharField(validators=[validatePassword])

    def clean(self):
        cleanedData = super().clean()
        password = cleanedData.get('password')
        passwordCheck = cleanedData.get('passwordCheck')

        if password != passwordCheck:
            self.errors['check'] = '密碼與確認密碼不符，請確認後重新輸入！'

        return cleanedData
