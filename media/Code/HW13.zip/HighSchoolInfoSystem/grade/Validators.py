#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: Validators.py 2190 2022-02-09 03:17:02Z Jacky $
#
# Copyright (c) 2022 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Jacky $
# $Date: 2022-02-09 11:17:02 +0800 (週三, 09 二月 2022) $
# $Revision: 2190 $

import re

from django.core.exceptions import ValidationError


# User.
def validateUsername(username):
    pattern = r'^[a-zA-Z0-9]+$'
    if not re.match(pattern, username):
        raise ValidationError(
                  message='請輸入由大小寫英文與數字組成的使用者名稱！'
              )

def validateName(name):
    pattern = r'^[\u4e00-\u9fa5]+$'
    if not re.match(pattern, name):
        raise ValidationError(
                  message='請輸入中文姓名！'
              )

def validatePhone(phone):
    pattern = r'09\d{8}$'
    if not re.match(pattern, phone):
        raise ValidationError(
                  message='請輸入 09 開頭的 10 碼手機號碼！'
              )

def validateEmail(email):
    pattern = r'^[a-zA-Z0-9_\-\.]+@[a-zA-Z0-9_\-\.]+\.([a-zA-Z]{2,5})$'
    if not re.match(pattern, email):
        raise ValidationError(
                  message='請輸入符合格式的電子郵件！'
              )


# Grade.
def validateGrade(grade):
    if grade > 100 or grade < 0:
        raise ValidationError(
                  message='成績請輸入 0 ~ 100 的整數。'
              )


# Password form.
def validatePassword(password):
    pattern = r'^[a-zA-Z0-9]+$'
    if not re.match(pattern, password):
        raise ValidationError(
                  message='請輸入由大小寫英文與數字組成的密碼！'
              )


