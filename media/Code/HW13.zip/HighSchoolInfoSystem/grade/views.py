#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: views.py 2211 2022-02-20 09:25:53Z Jacky $
#
# Copyright (c) 2022 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Jacky $
# $Date: 2022-02-20 17:25:53 +0800 (週日, 20 二月 2022) $
# $Revision: 2211 $

import secrets

from django.contrib import auth
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.paginator import Paginator
from django.db.models import Sum, Avg, F, Func
from django.http.response import JsonResponse
from django.shortcuts import render, redirect
from django.urls import reverse
from django.views import View
from django.views.generic.list import ListView
from django.views.generic.edit import UpdateView, DeleteView

from .models import Class, User, Semester, Grade
from .Forms import PasswordForm

class HomePageView(View):

    def get(self, request):
        return render(request, 'grade/HomePage.html')


class LoginView(View):

    def get(self, request):
        return render(request, 'grade/Login.html')

    def post(self, request):
        if request.user.is_authenticated:

            return redirect(reverse('home'))
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        user = auth.authenticate(username=username, password=password)

        if user is not None and user.is_active:
            auth.login(request, user)
            return redirect(reverse('home'))
        else:
            return render(request, 'grade/Login.html', locals())


class LogoutView(View):

    def post(self, request):
        auth.logout(request)
        return redirect(reverse('home'))


class EditSelfView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):

    permission_required = ('grade.readSelf', 'grade.editSelf')

    model = User
    fields = ['username', 'name', 'phone', 'email']

    template_name = 'grade/EditSelf.html'

    def get_success_url(self):
        return self.request.path


class EditSelfPasswordView(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = 'grade.editSelf'

    model = User
    fields = ['password']

    template_name = 'grade/EditPassword.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, context={'user': request.user})

    def post(self, request, *args, **kwargs):
        password = request.POST['password']
        passwordCheck = request.POST['passwordCheck']

        if password and password == passwordCheck:
            request.user.set_password(password)
            request.user.save()
            auth.update_session_auth_hash(request, request.user)

        return redirect(reverse('editSelf', kwargs={'pk': request.user.id}))

    def get_success_url(self):
        return reverse('editSelf', kwargs={'pk':self.object.id})


class EditSystemSemesterView(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = ('grade.readSemester', 'grade.createSemester')

    def get(self, request):
        semester = Semester.objects.last()

        context = {
            'semester': semester
        }

        return render(request, 'grade/EditSystem.html', context=context)

    def post(self, request):
        semester = Semester.createSemester()

        context = {
            'semester': semester
        }

        return render(request, 'grade/EditSystem.html', context=context)


class TeacherInfoView(LoginRequiredMixin, PermissionRequiredMixin, ListView):

    permission_required = 'grade.readTeacher'

    model = User

    template_name = 'grade/AllTeacherInfo.html'

    def get_queryset(self):
        if 'q' in self.request.GET:
            q = self.request.GET['q']
            queryset = User.teachers.filter(name__contains=q)
        else:
            queryset = User.teachers.all()

        return queryset


class CreateTeacherView(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = 'grade.createTeacher'

    model = User
    fields = ['username', 'password', 'name', 'phone', 'email' ,'clazz']
    context_object_name = 'teacher'

    template_name = 'grade/CreateTeacher.html'

    def get(self, request, *args, **kwargs):
        return render(request,
                      self.template_name,
                      context={
                          'userCountAndPasswordList':
                          enumerate([secrets.token_hex(8) for _ in range(User.MAX_USER_CREATED_ONCE)])
                      }
               )

    def post(self, request, *args, **kwargs):
        for i in range(User.MAX_USER_CREATED_ONCE):
            username = request.POST[f'username{i}']
            if username:
                # create class.
                className = request.POST[f'class{i}']
                clazz = Class.objects.filter(name=className).first()
                if not clazz:
                    clazz = Class(name=className)
                    clazz.save()

                name = request.POST[f'name{i}']
                if not name:
                    name = '新使用者'
                phone = request.POST[f'phone{i}']
                if not phone:
                    phone = '0900000000'
                email = request.POST[f'email{i}']

                teacher = User.objects.create(
                            username=username,
                            name=name,
                            clazz=clazz,
                            phone=phone,
                            email=email
                          )
                password = request.POST[f'password{i}']
                teacher.groups.set([User.GROUP_TEACHER])
                teacher.set_password(password)
                teacher.save()
            else:
                break
        return redirect(reverse('teacherInfo'))


class EditTeacherView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):

    permission_required = 'grade.updateTeacher'

    model = User
    fields = ['username', 'name', 'phone', 'email']
    context_object_name = 'teacher'

    template_name = 'grade/EditTeacher.html'

    def get_success_url(self):
        return reverse('teacherInfo')


class EditTeacherPasswordView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):

    permission_required = 'grade.updateTeacher'

    model = User
    form = PasswordForm()
    fields = ['password']
    context_object_name = 'teacher'

    template_name = 'grade/EditTeacherPassword.html'

    def post(self, request, *args, **kwargs):
        form = PasswordForm(request.POST)
        context = {'teacher': User.teachers.get(id=kwargs['pk'])}

        if form.is_valid():
            password = form.cleaned_data.get('password')
            teacher = super().get_object()
            teacher.set_password(password)
            teacher.save()
            return redirect(reverse('editTeacher', kwargs=kwargs))

        context['form'] = form
        return render(request, self.template_name, context)

    def get_success_url(self):
        return reverse('editTeacher', kwargs={'pk': self.pk})


class DeleteTeacehrView(DeleteView):

    model = User

    template_name = 'grade/DeleteTeacher.html'
    context_object_name = 'teacher'

    def get_success_url(self):
        return reverse('teacherInfo')


class StudentInfoView(LoginRequiredMixin, PermissionRequiredMixin, ListView):

    permission_required = 'grade.readStudent'

    model = User

    template_name = 'grade/AllStudentInfo.html'

    def get_queryset(self):
        queryDict = {}
        # Director.
        if self.request.user.groups.first().id == self.request.user.GROUP_DIRECTOR:
            # If 'GET' not null.
            getValue = self.request.GET
            if getValue:
                # Get 'q' value.
                if 'q' in getValue:
                    queryDict['name__contains'] = getValue['q']
                # Get 'class' value.
                if 'class' in getValue:
                    clazz = getValue['class']
                    if clazz:
                        queryDict['clazz'] = clazz
                queryset = User.students.filter(**queryDict)
            else:
                queryset = User.students.all()
        # Teacher.
        elif self.request.user.groups.first().id == self.request.user.GROUP_TEACHER:
            queryDict['clazz'] = self.request.user.clazz
            getValue = self.request.GET
            if 'q' in getValue:
                queryDict['name__contains'] = getValue['q']
            queryset = User.students.filter(**queryDict)

        # Only get the first 10 data.
        if len(queryset) > 10:
            queryset = queryset[:10]

        return queryset

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.user.groups.first().id == self.request.user.GROUP_DIRECTOR:
            context['classList'] = [(clazz.id, clazz.name) for clazz in Class.objects.all()]

            if 'class' in self.request.GET:
                clazzId = self.request.GET['class']
                if clazzId:
                    context['clazz'] = int(clazzId)

        return context


def getStudentScrollLoadingTable(request):

    queryDict = {}
    # Director.
    if request.user.groups.first().id == request.user.GROUP_DIRECTOR:
        # If 'GET' not null.
        getValue = request.GET
        if getValue:
            # Get 'q' value.
            if 'q' in getValue:
                queryDict['name__contains'] = getValue['q']
            # Get 'class' value.
            if 'class' in getValue:
                clazz = getValue['class']
                if clazz:
                    queryDict['clazz'] = clazz
    # Teacher.
    elif request.user.groups.first().id == request.user.GROUP_TEACHER:
        queryDict['clazz'] = request.user.clazz
        getValue = request.GET
        if 'q' in getValue:
            queryDict['name__contains'] = getValue['q']

    students = User.students.filter(**queryDict).order_by('id')
    paginator = Paginator(students, 10)
    pageNumber = request.GET.get('page')
    if pageNumber.isdigit():
        pageNumber = int(pageNumber)
        maxLength = paginator.num_pages
        if pageNumber < maxLength:
            studentList = paginator.get_page(pageNumber)
            html = render(request, 'grade/StudentScrollLoadingTable.html', {'studentList': studentList}).content
            html = html.decode('UTF-8')
        else:
            html = None
    else:
        html = None

    import time
    time.sleep(0.5)

    return JsonResponse({'html': html, 'maxLength': maxLength})


class CreateStudentView(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = 'grade.createStudent'

    model = User
    fields = ['username', 'password', 'name', 'phone','clazz']
    context_object_name = 'student'

    template_name = 'grade/CreateStudent.html'

    def get(self, request, *args, **kwargs):
        return render(request,
                      self.template_name,
                      context={
                          'userCountAndPasswordList':
                              enumerate([secrets.token_hex(8) for _ in range(User.MAX_USER_CREATED_ONCE)]),
                          'classList': [(clazz.id, clazz.name) for clazz in Class.objects.all()]
                      }
               )

    def post(self, request, *args, **kwargs):
        # Get the class.
        classId = request.POST['class']
        clazz = Class.objects.get(id=classId)

        for i in range(User.MAX_USER_CREATED_ONCE):
            username = request.POST[f'username{i}']
            if username:
                name = request.POST[f'name{i}']
                if not name:
                    name = '新使用者'
                phone = request.POST[f'phone{i}']
                if not phone:
                    phone = '0900000000'

                student = User.objects.create(
                            username=username,
                            name=name,
                            clazz=clazz,
                            phone=phone,
                          )
                password = request.POST[f'password{i}']
                student.groups.set([User.GROUP_STUDENT])
                student.set_password(password)
                student.save()
            else:
                break
        return redirect(reverse('studentInfo'))


class EditStudentView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):

    permission_required = 'grade.updateStudent'

    model = User
    fields = ['name', 'phone']
    context_object_name = 'student'

    template_name = 'grade/EditStudent.html'

    def get_success_url(self):
        return reverse('studentInfo')


class EditStudentPasswordView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):

    permission_required = 'grade.updateStudent'

    model = User
    fields = ['password']
    context_object_name = 'student'

    template_name = 'grade/EditStudentPassword.html'

    def post(self, request, *args, **kwargs):
        form = PasswordForm(request.POST)
        context = {'student': User.students.get(id=kwargs['pk'])}

        if form.is_valid():
            password = form.cleaned_data.get('password')
            student = super().get_object()
            student.set_password(password)
            student.save()
            return redirect(reverse('editStudent', kwargs=kwargs))

        context['form'] = form
        return render(request, self.template_name, context)

    def get_success_url(self):
        return reverse('editStudent', kwargs=self.kwargs)


class DeleteStudentView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):

    permission_required = 'grade.deleteStudent'

    model = User

    template_name = 'grade/DeleteStudent.html'
    context_object_name = 'student'

    def get_success_url(self):
        return reverse('studentInfo')


class StudentGradeView(LoginRequiredMixin, PermissionRequiredMixin, ListView):

    permission_required = 'grade.readGrade'

    model = User

    template_name = 'grade/AllStudentGrade.html'

    def get_queryset(self):

        # Get students and filter by students' info.
        queryDict = {}
        getValue = self.request.GET

        # Director.
        if self.request.user.groups.first().id == self.request.user.GROUP_DIRECTOR:
            # If 'GET' not null.
            if getValue:
                # Get 'q' value.
                if 'q' in getValue:
                    queryDict['name__contains'] = getValue['q']
                # Get 'class' value.
                if 'class' in getValue:
                    clazz = getValue['class']
                    if clazz:
                        queryDict['clazz'] = clazz
                students = User.students.filter(**queryDict).prefetch_related('grade_set')
            else:
                students = User.students.all().prefetch_related('grade_set')

        # Teacher.
        elif self.request.user.groups.first().id == self.request.user.GROUP_TEACHER:
            queryDict['clazz'] = self.request.user.clazz
            if 'q' in self.request.GET:
                queryDict['name__contains'] = self.request.GET['q']
            students = User.students.filter(**queryDict).prefetch_related('grade_set')

        # Student.
        elif self.request.user.groups.first().id == self.request.user.GROUP_STUDENT:
            students = User.students.filter(id=self.request.user.id).prefetch_related('grade_set')

        # Filter the students' grades by semester and test No.
        queryDict= {}

        # Filter by semester.
        if 'semester' in self.request.GET:
            semesterId = int(self.request.GET['semester'])
            semester = Semester.objects.get(id=semesterId)
        else:
            semester = Semester.objects.last()
        queryDict['semester'] = semester.id

        # Filter by testNo.
        if 'testNo' in self.request.GET:
            testNo = self.request.GET['testNo']
            if testNo:
                testNo = int(testNo)
                queryDict['testNo'] = testNo

        for student in students:
            student.grade = student.grade_set.filter(**queryDict)
            # TODO: student.__grades
        return students

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.user.groups.first().id == self.request.user.GROUP_DIRECTOR:
            context['classList'] = [(clazz.id, clazz.name) for clazz in Class.objects.all()]

            if 'class' in self.request.GET:
                clazzId = self.request.GET['class']
                if clazzId:
                    context['clazz'] = int(clazzId)

        context['semesterList'] = reversed([(semester.id, semester.name) for semester in Semester.objects.all()])
        context['testNoList'] = [testNo[0] for testNo in Grade.TEST_NO]
        context['studentList'] = list(self.get_queryset())

        if 'semester' in self.request.GET:
            context['semester'] = int(self.request.GET['semester'])
        if 'class' in self.request.GET:
            clazz = self.request.GET['class']
            context['class'] = clazz
            if clazz:
                context['class'] = int(clazz)
        if 'testNo' in self.request.GET:
            testNo = self.request.GET['testNo']
            context['testNo'] = testNo
            if testNo:
                context['testNo'] = int(testNo)

        return context


class CreateStudentGradeView(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = 'grade.createGrade'

    model = Grade
    fields = ['testNo', 'chinese', 'english', 'math']
    context_object_name = 'student'

    template_name = 'grade/createStudentGrade.html'

    def get(self, request, *args, **kwargs):
        # 'GET' value.
        if request.GET:
            if request.user.groups.first().id == User.GROUP_DIRECTOR:
                classId = int(request.GET['class'])
                classList = Class.objects.all()
            else:
                classId = request.user.clazz.id
                classList = None

            students = User.students.filter(clazz=classId)
            testNo = int(request.GET['testNo'])
            return render(request,
                          self.template_name,
                          context={
                              'classList': classList,
                              'testNoList': [testNo[0] for testNo in Grade.TEST_NO],
                              'studentList': enumerate(students),
                              'testNo': testNo,
                              'clazz': classId
                          }
                   )

        # Without 'GET' any value.
        if request.user.groups.first().id == User.GROUP_DIRECTOR:
            classList = Class.objects.all()
        else:
            classList = None

        return render(request,
                      self.template_name,
                      context={
                          'classList': classList,
                          'testNoList': [testNo[0] for testNo in Grade.TEST_NO],
                      }
               )

    def post(self, request, *args, **kwargs):
        # Get the class and students in this class.
        classId = int(request.POST['class'])
        studentList = User.students.filter(clazz=classId)

        for i in range(len(studentList)):
            studentUserId = request.POST[f'studentUserId{i}']
            chinese = request.POST[f'chinese{i}']
            english = request.POST[f'english{i}']
            math = request.POST[f'math{i}']

            # Set default grade = 0.
            if not chinese:
                chinese = 0
            if not english:
                english = 0
            if not math:
                math = 0

            # Convert the grade value to int.
            chinese = int(chinese)
            english = int(english)
            math = int(math)

            testNo = int(request.POST['testNo'])
            student = User.students.get(id=studentUserId)
            currentSemester = Semester.objects.last()
            Grade.objects.create(
                testNo=testNo,
                chinese=chinese,
                english=english,
                math=math,
                user=student,
                semester=currentSemester,
            )

        return redirect(reverse('studentGrade'))


class EditStudentGradeView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):

    permission_required = 'grade.updateGrade'

    model = Grade
    fields = ['chinese', 'english', 'math']
    context_object_name = 'grade'

    template_name = 'grade/EditStudentGrade.html'

    def get_success_url(self):
        return reverse('studentGrade')


class DeleteStudentGradeView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):

    permission_required = 'grade.deleteGrade'

    model = Grade

    template_name = 'grade/DeleteStudentGrade.html'
    context_object_name = 'grade'

    def get_success_url(self):
        return reverse('studentGrade')


class StudentRankView(LoginRequiredMixin, PermissionRequiredMixin, ListView):

    permission_required = ('grade.readGrade', 'grade.readStudent')

    model = Grade

    template_name = 'grade/AllStudentRank.html'

    def get_queryset(self, reverse=False):
        queryDict = {}
        getValue = self.request.GET

        # Filter by user info.
        # Director.
        if self.request.user.groups.first().id == self.request.user.GROUP_DIRECTOR:
            if 'q' in getValue:
                queryDict['user__name__contains'] = getValue['q']
            if 'class' in getValue:
                clazz = getValue['class']
                if clazz:
                    queryDict['user__clazz'] = clazz
        # Teacher.
        elif self.request.user.groups.first().id == self.request.user.GROUP_TEACHER:
            clazz = self.request.user.clazz
            if 'q' in getValue:
                queryDict['user__name__contains'] = getValue['q']

        # Filter by testNo.
        if 'testNo' in getValue:
            testNo = getValue['testNo']
            if testNo:
                testNo = int(testNo)
            else:
                testNo = 1
        else:
            testNo = 1

        queryDict['testNo'] = testNo

        # Filter by semester.
        if 'semester' in getValue:
            semesterId = int(getValue['semester'])
            semester = Semester.objects.get(id=semesterId)
        else:
            semester = Semester.objects.last()

        queryDict['semester'] = semester.id

        if reverse:
            grades = Grade.objects.filter(**queryDict).\
                        annotate(sum=F('chinese')+F('english')+F('math')).order_by('sum')
            return grades

        grades = Grade.objects.filter(**queryDict).\
                    annotate(sum=F('chinese') + F('english') + F('math')).order_by('-sum')

        return grades

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.user.groups.first().id == self.request.user.GROUP_DIRECTOR:
            context['classList'] = [(clazz.id, clazz.name) for clazz in Class.objects.all()]

            if 'class' in self.request.GET:
                clazzId = self.request.GET['class']
                if clazzId:
                    context['clazz'] = int(clazzId)

        context['semesterList'] = reversed([(semester.id, semester.name) for semester in Semester.objects.all()])
        context['testNoList'] = [testNo[0] for testNo in Grade.TEST_NO]
        context['gradeList'] = list(self.get_queryset())

        if 'semester' in self.request.GET:
            context['semester'] = int(self.request.GET['semester'])
        if 'class' in self.request.GET:
            clazz = self.request.GET['class']
            context['class'] = clazz
            if clazz:
                context['class'] = int(clazz)

        if 'testNo' in self.request.GET:
            testNo = self.request.GET['testNo']
            context['testNo'] = testNo
            if testNo:
                context['testNo'] = int(testNo)

        return context

    def get(self, request, *args, **kwargs):
        if 'reverse' in request.GET:
            reverse = request.GET.get('reverse')
            if reverse.isdigit():
                reverse = int(reverse)
            grades = self.get_queryset(bool(reverse))
            return render(request, 'grade/StudentRankTable.html', {'gradeList': grades})
        return super().get(request, *args, **kwargs)


class SubjectScoreView(LoginRequiredMixin, PermissionRequiredMixin, ListView):

    permission_required = ('grade.readGrade', 'grade.readStudent')

    model = Grade

    template_name = 'grade/AllSubjectScore.html'

    class SubjectScore():
        chineseSum = 0
        chineseAvg = 0
        englishSum = 0
        englishAvg = 0
        mathSum = 0
        mathAvg = 0

        def __init__(self, testNo):
            self.testNo = testNo

    class Round(Func):
        function = 'ROUND'
        arity = 2

    def get_queryset(self):
        queryDict = {}
        getValue = self.request.GET

        # Filter by user info.
        # Director.
        if self.request.user.groups.first().id == self.request.user.GROUP_DIRECTOR:
            if 'q' in getValue:
                queryDict['user__name__contains'] = getValue['q']
            if 'class' in getValue:
                clazz = getValue['class']
                if clazz:
                    queryDict['user__clazz'] = clazz
        # Teacher.
        elif self.request.user.groups.first().id == self.request.user.GROUP_TEACHER:
            clazz = self.request.user.clazz
            if 'q' in getValue:
                queryDict['user__name__contains'] = getValue['q']

        # Filter by testNo.
        if 'testNo' in getValue:
            testNo = getValue['testNo']
            if testNo:
                testNo = int(testNo)
                queryDict['testNo'] = testNo

        # Filter by semester.
        if 'semester' in getValue:
            semesterId = int(getValue['semester'])
            semester = Semester.objects.get(id=semesterId)
        else:
            semester = Semester.objects.last()

        queryDict['semester'] = semester.id

        grades = Grade.objects.filter(**queryDict)

        # Calculate subject score.
        subjectScoreList = []
        for i in Grade.TEST_NO:
            subjectScore = self.SubjectScore(i[0])
            aggregateValue = grades.filter(testNo=i[0]).\
                                aggregate(
                                    Sum('chinese'),
                                    Sum('english'),
                                    Sum('math'),
                                    chinese__avg=self.Round(Avg('chinese'), 2.),
                                    english__avg=self.Round(Avg('english'), 2.),
                                    math__avg=self.Round(Avg('math'), 2.)
                                )
            if aggregateValue['chinese__sum'] != 0 and not aggregateValue['chinese__sum']:
                # choose any column in 'aggregateValue', if null -> continue.
                continue

            subjectScore.chineseSum = aggregateValue['chinese__sum']
            subjectScore.chineseAvg = aggregateValue['chinese__avg']
            subjectScore.englishSum = aggregateValue['english__sum']
            subjectScore.englishAvg = aggregateValue['english__avg']
            subjectScore.mathSum = aggregateValue['math__sum']
            subjectScore.mathAvg = aggregateValue['math__avg']
            subjectScoreList.append(subjectScore)

        return subjectScoreList

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.user.groups.first().id == self.request.user.GROUP_DIRECTOR:
            context['classList'] = [(clazz.id, clazz.name) for clazz in Class.objects.all()]

            if 'class' in self.request.GET:
                clazzId = self.request.GET['class']
                if clazzId:
                    context['clazz'] = int(clazzId)

        context['semesterList'] = reversed([(semester.id, semester.name) for semester in Semester.objects.all()])
        context['testNoList'] = [testNo[0] for testNo in Grade.TEST_NO]
        context['subjectScoreList'] = list(self.get_queryset())

        if 'semester' in self.request.GET:
            context['semester'] = int(self.request.GET['semester'])
        if 'class' in self.request.GET:
            clazz = self.request.GET['class']
            context['class'] = clazz
            if clazz:
                context['class'] = int(clazz)

        if 'testNo' in self.request.GET:
            testNo = self.request.GET['testNo']
            context['testNo'] = testNo
            if testNo:
                context['testNo'] = int(testNo)

        return context


def getTeacherAutocomplete(request):

    q = request.GET['q']

    names = User.teachers.filter(name__contains=q).values('name')# values_list() 才對
    # django object is not serializable.

    return JsonResponse(list(names), safe=False)


def getStudentAutocomplete(request):

    queryDict = {}
    # Director.
    if request.user.groups.first().id == request.user.GROUP_DIRECTOR:
        # If 'GET' not null.
        getValue = request.GET
        if getValue:
            # Get 'q' value.
            if 'q' in getValue:
                queryDict['name__contains'] = getValue['q']
            # Get 'class' value.
            if 'class' in getValue:
                clazz = getValue['class']
                if clazz:
                    queryDict['clazz'] = clazz
            names = User.students.filter(**queryDict).values('name')
        else:
            names = User.students.all().values('name')
    # Teacher.
    elif request.user.groups.first().id == request.user.GROUP_TEACHER:
        queryDict['clazz'] = request.user.clazz
        getValue = request.GET
        if 'q' in getValue:
            queryDict['name__contains'] = getValue['q']
        names = User.students.filter(**queryDict).values('name') # values_list() 才對

    return JsonResponse(list(names), safe=False)

