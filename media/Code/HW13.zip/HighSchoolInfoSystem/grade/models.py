#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: models.py 2192 2022-02-09 03:26:46Z Jacky $
#
# Copyright (c) 2022 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Jacky $
# $Date: 2022-02-09 11:26:46 +0800 (週三, 09 二月 2022) $
# $Revision: 2192 $

from django.db import models
from django.contrib.auth.models import AbstractUser, UserManager

from .Validators import validateEmail, validateGrade, validateName, validatePhone, validateUsername


GROUP_DIRECTOR = 1
GROUP_TEACHER = 2
GROUP_STUDENT = 3


class StudentManager(models.Manager):

    def get_queryset(self):
        return super().get_queryset().filter(groups=GROUP_STUDENT)


class TeacherManager(models.Manager):

    def get_queryset(self):
        return super().get_queryset().filter(groups=GROUP_TEACHER)


class DirectorManager(models.Manager):

    def get_queryset(self):
        return super().get_queryset().filter(groups=GROUP_DIRECTOR)


class User(AbstractUser):

    ''' Models' Settings '''
    # Remove some columns that I don't need.
    first_name = None
    last_name = None

    # Customize some existed columns.
    username = models.CharField(max_length=15, unique=True, null=True, validators=[validateUsername])
    email = models.EmailField(max_length=50, null=True, blank=True, validators=[validateEmail])

    # Add my columns.
    name = models.CharField(max_length=20, default='新使用者', validators=[validateName])
    phone = models.CharField(max_length=15, default='0900000000', validators=[validatePhone])

    # Set foreign key.
    clazz = models.ForeignKey('Class', on_delete=models.PROTECT, null=True, blank=True)

    # Set REQUIRED_FIELDS.
    REQUIRED_FIELDS = []

    # Replace the USER_NAME_FIELD.
    USER_NAME_FIELD = 'username'

    # Set objects.
    objects = UserManager()
    directors = DirectorManager()
    teachers = TeacherManager()
    students = StudentManager()


    class Meta:
        # Set permissions.
        permissions = (
            # Self.
            ('readSelf', 'readSelf'),
            ('editSelf', 'editSelf'),
            # Teacher.
            ('readTeacher', 'readTeacher'),
            ('createTeacher', 'createTeacher'),
            ('updateTeacher', 'updateTeacher'),
            ('deleteTeacehr', 'deleteTeacher'),
            # Director.
            ('readStudent', 'readStudent'),
            ('createStudent', 'createStudent'),
            ('updateStudent', 'updateStudent'),
            ('deleteStudent', 'deleteStudent'),
        )

    ''' O-O Settings. '''
    # Set constant.
    GROUP_DIRECTOR = 1
    GROUP_TEACHER = 2
    GROUP_STUDENT = 3
    MAX_USER_CREATED_ONCE = 5


class Class(models.Model):

    ''' Model's settings '''
    name = models.CharField(max_length=3)

    class Meta:
        # Set permissions.
        permissions = (
            ('readClass', 'readClass'),
            ('createClass', 'createClass'),
            )

    def __str__(self):
        return self.name


class Semester(models.Model):

    ''' Model's settings '''
    name = models.CharField(max_length=5)

    class Meta:
        # Set permissions.
        permissions = (
            ('readSemester', 'readSemester'),
            ('createSemester', 'createSemester'),
            )

    @staticmethod
    def createSemester():
        currentSemester = Semester.objects.last()
        splittedSemesterName = currentSemester.name.split('-')
        if splittedSemesterName[-1] == '2':
            newSemesterName = str(int(splittedSemesterName[0]) + 1) + '-1'
        else:
            newSemesterName = splittedSemesterName[0] + '-2'

        newSemester = Semester(name=newSemesterName)
        newSemester.save()

        return newSemester


class Grade(models.Model):

    ''' Model's settings '''
    TEST_NO = (
        (1, 'First exam'),
        (2, 'Second exam'),
        (3, 'Final exam')
    )

    testNo = models.PositiveIntegerField(choices=TEST_NO)
    chinese = models.PositiveIntegerField(validators=[validateGrade])
    english = models.PositiveIntegerField(validators=[validateGrade])
    math = models.PositiveIntegerField(validators=[validateGrade])

    _sum = None
    _avg = None

    @property
    def summ(self):
        if self._sum:
            return self._sum

        self._sum = self.chinese + self.english + self.math
        return self._sum

    @property
    def avg(self):
        if self._avg:
            return self._avg

        self._avg = round(self.summ / 3.0, 2)
        return self._avg


    # Set foreign keys.
    user = models.ForeignKey('User', on_delete=models.PROTECT, null=True)
    semester = models.ForeignKey('Semester', on_delete=models.PROTECT)

    class Meta:
        # Set permissions.
        permissions = (
            ('readGrade', 'readGrade'),
            ('createGrade', 'createGrade'),
            ('updateGrade', 'updateGrade'),
            ('deleteGrade', 'deleteGrade'),
        )
