#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: admin.py 2156 2022-01-09 17:57:15Z Jacky $
#
# Copyright (c) 2022 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Jacky $
# $Date: 2022-01-10 01:57:15 +0800 (週一, 10 一月 2022) $
# $Revision: 2156 $

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Class, Grade, Semester, User


@admin.register(Class)
class ClassAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')


@admin.register(Grade)
class GradeAdmin(admin.ModelAdmin):
    list_filter = ('semester', 'testNo')
    list_display = ('id', 'user', 'semester', 'testNo', 'chinese', 'english', 'math')


@admin.register(Semester)
class SemesterAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')


@admin.register(User)
class MyUserAdmin(UserAdmin):
    # customize fields that will show in the admin site.
    fieldsets = (
        (None, {'fields': ('username', 'password', 'groups', 'name', 'phone', 'email', 'clazz')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'password1', 'password2'),
        }),
    )

    list_display = ('id', 'username', 'name', 'phone', 'email', 'clazz')

'''
super user:
userId: Jacky
email: 60514st@gmail.com
password: 948794crazy
'''

