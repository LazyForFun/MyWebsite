#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: urls.py 2202 2022-02-14 22:34:39Z Jacky $
#
# Copyright (c) 2022 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Jacky $
# $Date: 2022-02-15 06:34:39 +0800 (週二, 15 二月 2022) $
# $Revision: 2202 $

from django.urls import path

from . import views

urlpatterns = [

    # Home.
    path('', views.HomePageView.as_view(), name='home'),

    # Login and logout.
    path('login', views.LoginView.as_view(), name='login'),
    path('logout', views.LogoutView.as_view(), name='logout'),

    # Edit self and edit self password.
    path('user/<int:pk>/edit', views.EditSelfView.as_view(), name='editSelf'),
    path('user/<int:pk>/password/edit', views.EditSelfPasswordView.as_view(), name='editSelfPassword'),

    # Create new semester. Only director can do this.
    path('system/semester', views.EditSystemSemesterView.as_view(), name='editSystem'),

    # CRUD teachers.
    path('teachers/', views.TeacherInfoView.as_view(), name='teacherInfo'),
    path('teachers/create', views.CreateTeacherView.as_view(), name='createTeacher'),
    path('teacher/<int:pk>/edit', views.EditTeacherView.as_view(), name='editTeacher'),
    path('teacehr/<int:pk>/password/edit/', views.EditTeacherPasswordView.as_view(), name='editTeacherPassword'),
    path('teacher/<int:pk>/delete', views.DeleteTeacehrView.as_view(), name='deleteTeacher'),
    path('teachers/autocomplete', views.getTeacherAutocomplete, name='teacherAutocomplete'),

    # CRUD students.
    path('students/', views.StudentInfoView.as_view(), name='studentInfo'),
    path('students/create', views.CreateStudentView.as_view(), name='createStudent'),
    path('student/<int:pk>/edit', views.EditStudentView.as_view(), name='editStudent'),
    path('student/<int:pk>/password/edit/', views.EditStudentPasswordView.as_view(), name='editStudentPassword'),
    path('student/<int:pk>/delete', views.DeleteStudentView.as_view(), name='deleteStudent'),
    path('students/autocomplete', views.getStudentAutocomplete, name='studentAutocomplete'),
    path('students/scroll_loading', views.getStudentScrollLoadingTable, name='studentScrollLoading'),

    # CRUD student grades.
    path('students/grades/', views.StudentGradeView.as_view(), name='studentGrade'),
    path('students/grades/create', views.CreateStudentGradeView.as_view(), name='createStudentGrade'),
    path('student/<int:studentId>/grade/<int:pk>/edit', views.EditStudentGradeView.as_view(), name='editStudentGrade'),
    path('student/<int:studentId>/grade/<int:pk>/delete',
         views.DeleteStudentGradeView.as_view(), name='deleteStudentGrade'),

    # Student rank and subject score.
    path('students/rank', views.StudentRankView.as_view(), name='studentRank'),
    path('subject_grade', views.SubjectScoreView.as_view(), name='subjectScore'),

]
