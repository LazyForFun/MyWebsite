#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: createstudent.py 2203 2022-02-14 22:54:37Z Jacky $
#
# Copyright (c) 2022 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Jacky $
# $Date: 2022-02-15 06:54:37 +0800 (週二, 15 二月 2022) $
# $Revision: 2203 $

import re

from django.core.management.base import BaseCommand
from django.db import transaction

from ...models import User, Class


class Command(BaseCommand):

    help = 'Create students account for testing.\n' + \
        'The username will be "testAccount" + "number", and the password will be "1234QQQQ".'

    # I have created a class for testing, and the id of this class is 19.
    TEST_ACCOUNT_CLASS_ID = 19

    def add_arguments(self, parser):
        parser.add_argument('studentNum', nargs='+', type=int)


    @transaction.atomic
    def handle(self, *args, **options):
        studentNum = options['studentNum'][0]

        lastTestAccountNum = -1
        lastTestAccount = User.students.filter(username__contains='testAccount').last()
        if lastTestAccount:
            lastTestAccountNum = int(re.findall(r'testAccount(\d+)', lastTestAccount.username)[0])

        for i in range(studentNum):
            student = User.objects.create(
                          username=f'testAccount{lastTestAccountNum + 1 + i}',
                          name='測試用學生',
                          clazz=Class.objects.get(id=self.TEST_ACCOUNT_CLASS_ID)
                      )
            student.groups.set([User.GROUP_STUDENT])
            student.set_password('1234QQQQ')
            student.save()

            print(f'Create student account for testing: {student.username}')

        print(f'Process completed. Created {studentNum} student account for testing.')
