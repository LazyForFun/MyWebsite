#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: _private.py 2183 2022-02-05 20:19:03Z Jacky $
#
# Copyright (c) 2021 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Jacky $
# $Date: 2022-02-06 04:19:03 +0800 (週日, 06 二月 2022) $
# $Revision: 2183 $
